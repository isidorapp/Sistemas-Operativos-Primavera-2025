// Funciones que Ud. debe programar
void nth_iniciar();
void nth_terminar();
int nPedir(int cat, int timeout);
void nDevolver();
