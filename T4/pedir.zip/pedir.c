#include <stdio.h>
#include <nthread-impl.h>
#include "pss.h"
#include "pedir.h"

// Variables globales
NthQueue *espera[2]; // Arreglo de dos colas
int recurso_oc; // 0 libre, 1 ocupado
int owner; // Thread dueño de la categoría

void nth_iniciar() {
    // Inicializar colas
    espera[0] = nth_makeQueue();
    espera[1] = nth_makeQueue();
    
    // Inicializar variables (recurso libre)
    recurso_oc = 0;
    owner = -1;
}

void nth_terminar() {
    // Limpiar colas
    nth_destroyQueue(espera[0]);
    nth_destroyQueue(espera[1]);
}

int nPedir(int cat, int timeout) {
    // Iniciar sección crítica
    START_CRITICAL;
    // Obtener thread actual 
    nThread self = nSelf();
    
    // Caso recurso ocupado
    if (recurso_oc) {
      // Encolar thread al final de su categoría
      nth_putBack(espera[cat], self);
      // Suspender thread actual
      suspend(WAIT_REQUEST);
      // Llamado a scheduler para ejecutar otro thread
      schedule();
      
    } else { // Caso recurso libre
      // Marcar como ocupado
      recurso_oc = 1;
      // Marcar categoría actual como dueña del recurso
      owner = cat;
    }
    
    // Salir de sección crítica
    END_CRITICAL;
    return 1;
}

void nDevolver() {
    // Iniciar sección crítica
    START_CRITICAL;
    
    // Caso recurso libre
    if (!recurso_oc) {
        END_CRITICAL;
        return;
    } 
    
    // Categorías opuestas 0 o 1
    int cat_opuesta = 1 - owner;
    // Puntero al siguiente thread para despertar
    nThread siguiente = NULL;

    // Casos recurso ocupado
    if (!nth_emptyQueue(espera[cat_opuesta])) {
        // Si hay threads esperando de la categoría opuesta
        // Sacar el primero de la cola opuesta
        siguiente = nth_getFront(espera[cat_opuesta]);
        // Marcar la otra categoría como dueña
        owner = cat_opuesta;
    }
    // Categoría actual
    else if (!nth_emptyQueue(espera[owner])) {
        // Si no hay threads de categoría opuesta pero sí
        // De la actual, sacar el primer thread de la cola
        siguiente = nth_getFront(espera[owner]);
    }
    // No hay categorías en espera
    else {
        // El recurso está libre
        recurso_oc = 0;
        // No hay dueño
        owner = -1;
        // Fin sección crítica
        END_CRITICAL;
        return;
    }

    // Si hay siguiente thread, despertarlo
    setReady(siguiente); // Cambia wait_acceder a ready
    // Llamado a scheduler
    schedule();
    
    // Fin sección crítica
    END_CRITICAL;
}
